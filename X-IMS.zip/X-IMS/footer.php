<footer style="
    text-align: center; 
    padding: 20px; 
    margin-top: 40px; 
    border-top: 1px solid #dee2e6; 
    color: #6c757d; 
    font-family: Arial, sans-serif;
">
    <p>&copy; <?php echo date("Y"); ?> Ethio Hopes Academy (Inventory Management System). All Rights Reserved.</p>
</footer>
</body>
</html>