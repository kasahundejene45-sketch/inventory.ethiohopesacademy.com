<?php
$db = new PDO('sqlite:equipment_system.db');

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Test if the ID is actually being received
    echo "Attempting to delete ID: " . $id . "<br>";

    $stmt = $db->prepare("DELETE FROM equipment WHERE id = ?");
    $result = $stmt->execute([$id]);

    if ($result) {
        echo "Query executed successfully. Rows affected: " . $stmt->rowCount();
    } else {
        echo "Query failed.";
    }
} else {
    echo "No ID provided in the URL.";
}
?>