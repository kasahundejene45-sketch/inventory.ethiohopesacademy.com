<?php
// includes/functions.php
require_once __DIR__ . '/../config/config.php';

function getInventory($pdo, $branch) {
    $stmt = $pdo->prepare("SELECT e.*, c.name as category_name FROM equipment e 
                          LEFT JOIN categories c ON e.category_id = c.id 
                          WHERE e.branch = ?");
    $stmt->execute([$branch]);
    return $stmt->fetchAll();
}

function checkOutItem($pdo, $id, $qty, $person, $branch) {
    // Wrap in a transaction to ensure data integrity
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("UPDATE equipment SET available_qty = available_qty - ? WHERE id = ? AND branch = ?");
        $stmt->execute([$qty, $id, $branch]);
        
        $tx = $pdo->prepare("INSERT INTO transactions (equipment_id, responsible_person, action_type, qty) VALUES (?, ?, 'CHECKOUT', ?)");
        $tx->execute([$id, $person, $qty]);
        
        $pdo->commit();
        return true;
    } catch (Exception $e) {
        $pdo->rollBack();
        return false;
    }
}
?>
 // 2. Safe Schema Migrations (Add missing columns dynamically)
    try {
        @$db->exec("ALTER TABLE equipment ADD COLUMN branch TEXT NOT NULL DEFAULT 'Main Campus'");
    } catch (Exception $e) {}
    try {
        @$db->exec("ALTER TABLE material_requests ADD COLUMN branch TEXT NOT NULL DEFAULT 'Main Campus'");
    } catch (Exception $e) {}
    try {
        @$db->exec("ALTER TABLE equipment ADD COLUMN registered_date TEXT DEFAULT CURRENT_DATE");
    } catch (Exception $e) {}
    try {
        @$db->exec("ALTER TABLE equipment ADD COLUMN due_date TEXT");
    } catch (Exception $e) {}

    // 3. Clean and Repair Single Digit / Broken Dates Safely via PHP
    try {
        $checkData = $db->query("SELECT id, registered_date FROM equipment")->fetchAll();
        if (!empty($checkData)) {
            $repairStmt = $db->prepare("UPDATE equipment SET registered_date = :today WHERE id = :id");
            foreach ($checkData as $row) {
                $dateVal = trim($row['registered_date'] ?? '');
                // If it's empty, null, or a broken single number (like 1, 4, 5), fix it
                if (strlen($dateVal) < 10 || empty($dateVal)) {
                    $repairStmt->execute([
                        ':today' => date('Y-m-d'),
                        ':id'    => $row['id']
                    ]);
                }
            }
        }
    } catch (Exception $e) {}

    // 4. Default Categories Seeding
    $defaultCategories = [
        'Lab Equipment', 'Electronics', 'Sports', 'Furniture', 
        'Medical', 'Agricultural', 'Hygiene', 'Construction', 'Stationary'
    ];
    
    foreach ($defaultCategories as $catName) {
        $chk = $db->prepare("SELECT COUNT(*) FROM categories WHERE name = ?");
        $chk->execute([$catName]);
        if ($chk->fetchColumn() == 0) {
            $ins = $db->prepare("INSERT INTO categories (name) VALUES (?)");
            $ins->execute([$catName]);
        }
    }

} catch (PDOException $e) {
    die("Database Connection Failed: " . $e->getMessage());
}

// ==========================================
// BACKEND API ROUTING (POST ACTIONS)
// ==========================================
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['logged_in']) && isset($_POST['action'])) {
    try {
        if ($_POST['action'] === 'register') {
            $stmt = $db->prepare("INSERT INTO equipment (asset_tag, name, category_id, total_qty, available_qty, unit_price, location, branch, registered_date, due_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $reg_date = !empty($_POST['registered_date']) ? $_POST['registered_date'] : date('Y-m-d');
            $due_date = !empty($_POST['due_date']) ? $_POST['due_date'] : null;
            
            $stmt->execute([
                $_POST['asset_tag'], $_POST['name'], $_POST['category_id'],
                $_POST['qty'], $_POST['qty'], floatval($_POST['unit_price'] ?? 0), $_POST['location'], $current_branch, $reg_date, $due_date
            ]);
            $message = "Equipment registered successfully under " . htmlspecialchars($current_branch) . "!";
        } 
        
        elseif ($_POST['action'] === 'add_custom_category') {
            $newCat = trim($_POST['category_name'] ?? '');
            if (!empty($newCat)) {
                $stmt = $db->prepare("INSERT OR IGNORE INTO categories (name) VALUES (?)");
                $stmt->execute([$newCat]);
                $message = "Category '" . htmlspecialchars($newCat) . "' successfully added to base registry systems!";
            }
        }

        elseif ($_POST['action'] === 'edit_equipment') {
            $id = intval($_POST['equipment_id']);
            $new_total = intval($_POST['qty']);
            
            $stmt = $db->prepare("SELECT total_qty, available_qty FROM equipment WHERE id = ? AND branch = ?");
            $stmt->execute([id, $current_branch]);
            $current = $stmt->fetch();
            
            if ($current) {
                $difference = $new_total - $current['total_qty'];
                $new_available = $current['available_qty'] + $difference;
                
                if ($new_available < 0) {
                    throw new Exception("Cannot reduce total stock boundaries below current checkout custody limits.");
                }

                $due_date = !empty($_POST['due_date']) ? $_POST['due_date'] : null;

                $stmt = $db->prepare("UPDATE equipment SET asset_tag = ?, name = ?, category_id = ?, total_qty = ?, available_qty = ?, unit_price = ?, location = ?, registered_date = ?, due_date = ? WHERE id = ? AND branch = ?");
                $stmt->execute([
                    $_POST['asset_tag'], $_POST['name'], $_POST['category_id'], 
                    $new_total, $new_available, floatval($_POST['unit_price'] ?? 0), $_POST['location'], $_POST['registered_date'], $due_date, $id, $current_branch
                ]);
                $message = "Asset parameters updated successfully!";
            }
        }
        
        elseif ($_POST['action'] === 'checkout') {
            $eqId = $_POST['equipment_id'];
            $qty = intval($_POST['qty']);
            $person = $_POST['responsible_person'];

            $eq = $db->prepare("SELECT available_qty FROM equipment WHERE id = ? AND branch = ?");
            $eq->execute([$eqId, $current_branch]);
            $available = $eq->fetchColumn();

            if ($available !== false && $available >= $qty) {
                $db->beginTransaction();
                $up = $db->prepare("UPDATE equipment SET available_qty = available_qty - ? WHERE id = ?");
                $up->execute([$qty, $eqId]);
                
                $tx = $db->prepare("INSERT INTO transactions (equipment_id, responsible_person, action_type, qty) VALUES (?, ?, 'CHECKOUT', ?)");
                $tx->execute([$eqId, $person, $qty]);
                $db->commit();
                $message = "Equipment checked out successfully!";
            } else {
                $message = "Error: Insufficient stock or branch constraint violation.";
            }
        }

        elseif ($_POST['action'] === 'return_portion') {
            $txId = intval($_POST['transaction_id']);
            $returnQty = intval($_POST['return_qty']);

            $txStmt = $db->prepare("SELECT t.* FROM transactions t JOIN equipment e ON t.equipment_id = e.id WHERE t.id = ? AND t.action_type = 'CHECKOUT' AND e.branch = ?");
            $txStmt->execute([$txId, $current_branch]);
            $tx = $txStmt->fetch();

            if ($tx) {
                if ($returnQty > $tx['qty'] || $returnQty <= 0) {
                    throw new Exception("Invalid return quantity specified.");
                }

                $db->beginTransaction();
                
                $upItem = $db->prepare("UPDATE equipment SET available_qty = available_qty + ? WHERE id = ?");
                $upItem->execute([$returnQty, $tx['equipment_id']]);
                
                $logTx = $db->prepare("INSERT INTO transactions (equipment_id, responsible_person, action_type, qty) VALUES (?, ?, 'RETURN', ?)");
                $logTx->execute([$tx['equipment_id'], $tx['responsible_person'], $returnQty]);

                if ($returnQty === $tx['qty']) {
                    $delTx = $db->prepare("DELETE FROM transactions WHERE id = ?");
                    $delTx->execute([$txId]);
                } else {
                    $upTx = $db->prepare("UPDATE transactions SET qty = qty - ? WHERE id = ?");
                    $upTx->execute([$returnQty, $txId]);
                }

                $db->commit();
                $message = "Return processed successfully!";
            }
        }

        elseif ($_POST['action'] === 'submit_material_request') {
            $stmt = $db->prepare("INSERT INTO material_requests (staff_name, department, item_description, requested_qty, purpose_note, urgency_level, branch) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $_POST['staff_name'], $_POST['department'], $_POST['item_description'],
                intval($_POST['requested_qty']), $_POST['purpose_note'], $_POST['urgency_level'], $current_branch
            ]);
            $message = "Material request logged to your branch inventory layout successfully!";
        }

        elseif ($_POST['action'] === 'update_request_status') {
            $stmt = $db->prepare("UPDATE material_requests SET status = ? WHERE id = ? AND branch = ?");
            $stmt->execute([$_POST['status'], intval($_POST['request_id']), $current_branch]);
            $message = "Request status tracking metric synchronized!";
        }

        elseif ($_POST['action'] === 'clear_material_logs') {
            $stmt = $db->prepare("DELETE FROM material_requests WHERE branch = ?");
            $stmt->execute([$current_branch]);
            $message = "Material request forms deleted for " . htmlspecialchars($current_branch) . "!";
        }
		
    } catch (Exception $e) {
        if($db->inTransaction()) $db->rollBack();
        $message = "System Error: " . $e->getMessage();
    }
}

// ==========================================
// BRANCH DATA ISOLATION ENGINE
// ==========================================
$categories = $db->query("SELECT * FROM categories ORDER BY name ASC")->fetchAll();

$stmt = $db->prepare("SELECT e.*, c.name as category_name FROM equipment e LEFT JOIN categories c ON e.category_id = c.id WHERE e.branch = ?");
$stmt->execute([$current_branch]);
$inventory = $stmt->fetchAll();

$stmt = $db->prepare("SELECT t.*, e.name as item_name, e.asset_tag FROM transactions t JOIN equipment e ON t.equipment_id = e.id WHERE t.action_type = 'CHECKOUT' AND e.branch = ? ORDER BY t.action_date DESC");
$stmt->execute([$current_branch]);
$activeCheckouts = $stmt->fetchAll();

$stmt = $db->prepare("SELECT * FROM material_requests WHERE branch = ? ORDER BY submission_date DESC");
$stmt->execute([$current_branch]);
$materialRequests = $stmt->fetchAll();

// Isolated Branch Metric Totals
$totalItems = $db->prepare("SELECT SUM(total_qty) FROM equipment WHERE branch = ?"); $totalItems->execute([$current_branch]); $totalItems = $totalItems->fetchColumn() ?: 0;
$totalCheckedOut = $db->prepare("SELECT SUM(t.qty) FROM transactions t JOIN equipment e ON t.equipment_id = e.id WHERE t.action_type = 'CHECKOUT' AND e.branch = ?"); $totalCheckedOut->execute([$current_branch]); $totalCheckedOut = $totalCheckedOut->fetchColumn() ?: 0;
$uniqueAssets = $db->prepare("SELECT COUNT(*) FROM equipment WHERE branch = ?"); $uniqueAssets->execute([$current_branch]); $uniqueAssets = $uniqueAssets->fetchColumn();
$totalCapitalValuation = $db->prepare("SELECT SUM(total_qty * unit_price) FROM equipment WHERE branch = ?"); $totalCapitalValuation->execute([$current_branch]); $totalCapitalValuation = $totalCapitalValuation->fetchColumn() ?: 0;

// Track overdue items dynamically
$overdueCount = 0;
$todayDate = date('Y-m-d');
foreach ($inventory as $item) {
    if (!empty($item['due_date']) && $item['due_date'] < $todayDate && $item['available_qty'] < $item['total_qty']) {
        $overdueCount++;
    }
}
?>