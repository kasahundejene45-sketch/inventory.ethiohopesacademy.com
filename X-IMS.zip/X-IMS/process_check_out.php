<?php
session_start();
$db = new PDO('sqlite:equipment_system.db');

if (isset($_POST['submit_return'])) {
    $tag = $_POST['asset_tag'];
    $qty = (int)$_POST['quantity'];

    try {
        $db->beginTransaction();

        // 1. Find the equipment by Asset Tag and increase stock
        $stmt = $db->prepare("UPDATE equipment SET stock = stock + ? WHERE asset_tag = ?");
        $stmt->execute([$qty, $tag]);

        // 2. Verify if the update actually found an item
        if ($stmt->rowCount() > 0) {
            // 3. Log the return in the transactions table
            $stmt = $db->prepare("INSERT INTO transactions (asset_tag, quantity, type) VALUES (?, ?, 'IN')");
            $stmt->execute([$tag, $qty]);
            
            $db->commit();
            header("Location: index.php?msg=returned");
        } else {
            throw new Exception("Asset Tag not found!");
        }
    } catch (Exception $e) {
        $db->rollBack();
        echo "Error: " . $e->getMessage();
    }
}
?>